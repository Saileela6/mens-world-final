package com.example.web.dto;

public class UserRegistrationdto {

}
